import React from "react"
import Component2 from "./Component2"
function Component1(){
    return(
        <React.Fragment>
         <Component2/>
         <h1>Component one</h1>
         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
         </React.Fragment>

)
}
export default Component1