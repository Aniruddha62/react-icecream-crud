import './Car.css'
let car = () =>{
    return(
        <div className="car">
            <img src="https://cdni.autocarindia.com/Utils/ImageResizer.ashx?n=https://cdni.autocarindia.com/ExtraImages/20230426032407_Untitled.png&w=700&c=1"
            <h1 style={{backgroundColor : "green",color : "white"}}>
                Car is a vehicle in react</h1>
            </div>
    )
}
export default car


