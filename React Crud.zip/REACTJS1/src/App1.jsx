import component1 from "./Component1.jsx";
function App1(){
    console.log("Welcome to reactjs");

    return (
        <div className="App1">
           <h1>Welcome to App1</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
        <component1/>
        <component1/>
        <component1/>
        <component1/>
        <component1/>
        <component1/>
        </div>
    )
    }
