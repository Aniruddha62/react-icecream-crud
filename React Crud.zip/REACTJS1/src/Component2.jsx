function Component2(){
    return (
        <>
        <h1>Component from</h1>
        </>
    )
}
export default Component2