import React from "react"
class Home extends React.Component{
    render(){
        return{
            <div className="d1">
              <h1>I am Home Content</h1>
              </div>
        }
    }
}
export default Home